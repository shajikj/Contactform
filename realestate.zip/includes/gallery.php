 <section class="container py-5">
    <h2 style="text-align: center;">Our Property</h2>
        <div class="row g-3">
            <div class="col-6 col-md-3">
                <img src="images/gallery/gallery1.jpg" class="img-fluid rounded shadow-sm">
            </div>
            <div class="col-6 col-md-3">
                <img src="images/gallery/gallery2.jpg" class="img-fluid rounded shadow-sm">
            </div>
            <div class="col-6 col-md-3">
                <img src="images/gallery/gallery3.jpg" class="img-fluid rounded shadow-sm">
            </div>
            <div class="col-6 col-md-3">
                <img src="images/gallery/gallery4.jpg" class="img-fluid rounded shadow-sm">
            </div>
        </div>
    </section>